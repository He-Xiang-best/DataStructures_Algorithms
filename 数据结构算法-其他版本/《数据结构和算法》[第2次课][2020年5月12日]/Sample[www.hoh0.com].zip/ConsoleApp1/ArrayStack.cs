﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class ArrayStack<T>
    {
        // 栈数组
        private readonly T[] _items;
        // 栈的大小
        private readonly int _size;
        // 栈中的元素个数
        private int _count;

        public ArrayStack(int size)
        {
            _items = new T[size];
            _size = size;
        }

        public bool Push(T item) {
            // 判断栈数组空间，如果满了就失败
            if (_count == _size) return false;
            _items[_count] = item;
            _count++;
            return true;
        }

        public T Pop() {
            if (_count == 0) return default;
            var tmp = _items[_count-1];
            _count--;
            return tmp;
        }
    }



}
