﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class Sample02
    {
        public static void InsertSort(int[] a) {
            if (a.Length <= 1) return;

            for (var i = 1; i < a.Length; i++) {
                var value = a[i];
                var j = i - 1;
                // 查找插入的位置
                for (; j >= 0; j--) {
                    // 比较
                    if (a[j] > value) {
                        // 移动数据
                        // K!
                        a[j+1] = a[j];  
                    } else {
                        break;
                    }
                }
                // 插入
                a[j+1] = value; 
            }

        }
    }
}
