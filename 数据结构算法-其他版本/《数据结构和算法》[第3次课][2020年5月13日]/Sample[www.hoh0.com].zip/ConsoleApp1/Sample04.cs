﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class Sample04
    {
        public static void MergeSort(int[] a)
        {
            MergeSort(a, 0, a.Length - 1);
        }

        public static void MergeSort(int[] a, int m, int n)
        {
            //递归终止条件
            if(m>=n) return;
            // 取m到n之间的中间位置 x
            var x = (m + n) / 2;
            // 分治递归
            MergeSort(a, m, x);
            MergeSort(a, x + 1, n);
            Merge(a, m, x, n);
        }

        public static void Merge(int[] a, int m, int x, int n)
        {
            var i = m;
            var j = x+1;
            var k = 0; 

            // 申请一个大小和a[m...n]一样的临时数组
            var tmp = new int[n - m + 1];

            // 比较
            while (i<=x && j<=n) {
                if (a[i] <= a[j]) {
                    tmp[k] = a[i];
                    k++;
                    i++;
                } else {
                    tmp[k] = a[j];
                    k++;
                    j++;
                }
            }

            
            // 判断哪个子数组有剩余的数据
            var start = i;
            var end = x;
            if (j <= n) {
                start = j;
                end = n;
            }

            // 将剩余的数据拷贝到临时数组tmp
            while (start <= end) {
                tmp[k] = a[start];
                k++;
                start++;
            }

            // 将tmp中的数组拷贝回
            for (i = 0; i <= n-m; i++) {
                a[m+i] = tmp[i];
            }
        }
    }
}
