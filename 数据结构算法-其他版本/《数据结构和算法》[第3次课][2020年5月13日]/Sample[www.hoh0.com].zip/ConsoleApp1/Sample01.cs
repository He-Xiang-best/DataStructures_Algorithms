﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class Sample01
    {
        public static void BubbleSort(int[] a) 
        {
            if (a.Length <= 1) return;

            for (var i = 0; i < a.Length; ++i) {
   
                var flag = false;
                for (var j = 0; j < a.Length - i - 1; j++) {
                    if (a[j] <= a[j + 1]) continue;
                    // 逆序度是K*3
                    var tmp = a[j];
                    a[j] = a[j+1];
                    a[j+1] = tmp;
                    flag = true;  
                }
                if (!flag) break; 
            }
        }
    }
}
