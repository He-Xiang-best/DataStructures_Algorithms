﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace ConsoleApp1
{
    public static class Sample03
    {
        public static void Run()
        {
            const int arrayCount = 10000;
            const int arraySize = 400;

            var arrList = new List<int[]>(arrayCount);
            var arrList1 = new List<int[]>(arrayCount);

            var watch = new Stopwatch();
            watch.Start();
            for (var i = 0; i < arrayCount; i++)
            {
                var rd = new Random();
                var arr = new int[arraySize];
                for (var j = 0; j < arraySize; j++)
                {
                    arr[j] = rd.Next(arraySize);
                }
                arrList.Add(arr);
                arrList1.Add((int[])arr.Clone());
            }
            
            watch.Stop();
            Console.WriteLine($"生成测试数据，耗时：{watch.ElapsedMilliseconds}ms");
            
            watch.Restart();
            foreach (var arr in arrList)
            {
                Sample01.BubbleSort(arr);
            }
            watch.Stop();
            Console.WriteLine($"冒泡排序，耗时：{watch.ElapsedMilliseconds}ms");

            watch.Restart();
            foreach (var arr in arrList1)
            {
                Sample02.InsertSort(arr);
            }
            watch.Stop();
            Console.WriteLine($"插入排序，耗时：{watch.ElapsedMilliseconds}ms");

        }
    }
}
