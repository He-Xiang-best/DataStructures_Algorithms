﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class Sample05
    {
        public static void QuickSort(int[] a)
        {
            QuickSort(a, 0, a.Length - 1);
        }

        public static void QuickSort(int[] a, int m, int n)
        {
            if (m >= n) return;

            // 获取分区点
            var x = Partition(a, m, n);
            QuickSort(a, m, x-1);
            QuickSort(a, x+1, n);
        }

        public static int Partition(int[] a, int m, int n) {
            var pivot = a[n];
            var i = m;

            int tmp;    
            for(var j = m; j < n; j++)
            {
                if (a[j] >= pivot) continue;
                if (i == j) {
                    i++;
                } else {
                    tmp = a[i];
                    a[i] = a[j];
                        
                    a[j] = tmp;
                    i++;
                }
            }

            tmp = a[i];
            a[i] = a[n];
            a[n] = tmp;
            return i;
        }
    }
}
