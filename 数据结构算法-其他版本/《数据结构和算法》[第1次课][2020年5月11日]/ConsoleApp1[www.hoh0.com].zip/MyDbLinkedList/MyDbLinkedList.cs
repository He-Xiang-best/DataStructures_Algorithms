﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyDbLinkedList
{
    public class MyDbLinkedList<T>
    {
        private DbNode<T> _head;
        private DbNode<T> _last;
        public int Count { get; private set; }

        public T this[int index]
        {
            get => GetNodeByIndex(index).Data;
            set => GetNodeByIndex(index).Data = value;
        }

        /// <summary>
        /// 根据索引获取节点
        /// </summary>
        /// <param name="index">索引</param>
        /// <returns></returns>
        private DbNode<T> GetNodeByIndex(int index)
        {
            if (index < 0 || index >= Count) throw new ArgumentOutOfRangeException("index", "索引超出范围");

            var currentNode = _head;

            for (var i = 0; i < index; i++)
            {
                currentNode = currentNode.Next;
            }

            return currentNode;
        }

        /// <summary>
        /// 在链表尾插入新结点
        /// </summary>
        /// <param name="value"></param>
        public void Add(T value)
        {
            var newNode = new DbNode<T>(value);
            if (_head == null)
            {
                _head = newNode;
                _last = newNode;
            }
            else
            {
                _last.Next = newNode;
                newNode.Prev = _last;
                _last = newNode;
            }
            Count++;
        }

        /// <summary>
        /// 在指定位置插入新结点
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        public void Insert(int index, T value)
        {
            var newNode = new DbNode<T>(value);
            if (index == 0)
            {
                if (_head == null)
                {
                    _head = newNode;
                    _last = newNode;
                }
                else
                {
                    newNode.Next = _head;
                    _head.Prev = newNode;
                    _head = newNode;
                }
            }
            else
            {
                var node = GetNodeByIndex(index);
                var prevNode = node.Prev;
                prevNode.Next = newNode;
                newNode.Prev = prevNode;
                newNode.Next = node;
                node.Prev = newNode;
            }
            Count++;
        }

        public void RemoveAt(int index)
        {
            if (index == 0)
            {
                _head = _head.Next;
            }
            else
            {
                var delNode = GetNodeByIndex(index);
                var prevNode = delNode.Prev;
                var nextNode = delNode.Next;
                prevNode.Next = nextNode;

                if (nextNode != null)
                {
                    nextNode.Prev = prevNode;
                }
                else
                {
                    _last = prevNode;
                }

            }
            Count--;
        }
    }
}
