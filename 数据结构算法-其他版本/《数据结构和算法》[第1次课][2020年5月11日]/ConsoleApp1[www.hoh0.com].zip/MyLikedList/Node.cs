﻿namespace MyLikedList
{
    public class Node<T>
    {
        // 结点中的数据
        public T Data;
        // 指向后继结点的指针
        public Node<T> Next;

        public Node(T data)
        {
            Data = data;    
            Next = null;
        }
    }
}
