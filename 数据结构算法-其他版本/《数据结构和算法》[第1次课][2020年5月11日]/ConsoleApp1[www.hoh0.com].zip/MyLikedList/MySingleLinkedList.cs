﻿using System;

namespace MyLikedList
{
    /// <summary>
    /// 单链表模拟实现
    /// </summary>
    public class MySingleLinkedList<T>
    {
        // 头结点
        private Node<T> _head;
        // 尾结点
        private Node<T> _last; 

        // 当前链表节点个数
        public int Count { get; private set; }

        /// <summary>
        /// 根据索引获取节点
        /// </summary>
        /// <param name="index">索引</param>
        /// <returns></returns>
        private Node<T> GetNodeByIndex(int index)
        {
            if (index < 0 || index >= Count) throw new ArgumentOutOfRangeException("index", "索引超出范围");

            // 将头结点设置为当前节点
            var currentNode = _head;

            // 循环Index次，每次循环都将currentNode设置为其后继节点
            // 循环完成后，最终的currentNode就是index代表的节点
            for (var i = 0; i < index; i++)
            {
                currentNode = currentNode.Next;
            }

            return currentNode;
        }

        /// <summary>
        /// 索引器
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public T this[int index]
        {
            get => GetNodeByIndex(index).Data;
            set => GetNodeByIndex(index).Data = value;
        }

        /// <summary>
        /// 在链表尾部插入结点
        /// </summary>
        /// <param name="value"></param>
        public void Add(T value)
        {
            var newNode = new Node<T>(value);
            if (_head == null)
            {   
                // 如果链表当前为空，同时设置头结点和尾结点
                _head = newNode;
                _last = newNode;
            }
            else
            {
                // 先将当前尾结点的的Next指针指向新节点
                _last.Next = newNode;
                // 再将新节点设置为尾结点
                _last = newNode;
            }

            Count++;
        }

        /// <summary>
        /// 移除指定位置的节点
        /// </summary>
        /// <param name="index"></param>
        public void RemoveAt(int index)
        {
            if (index < 0 || index > Count) throw new ArgumentOutOfRangeException("index", "索引超出范围");

            if (index == 0)
            {
                // 移除头部节点，
                _head = _head.Next;
            }
            else
            {
                // 非头部结点
                // 先查找待移除的前驱结点
                var prevNode = GetNodeByIndex(index - 1);
                // 待删除节点
                var deleteNode = prevNode.Next;
                // 前驱结点指向待删除节点Next
                prevNode.Next = deleteNode.Next;
            }

            Count--;
        }

        /// <summary>
        /// 在指定位置插入新节点
        /// </summary>
        /// <param name="index"></param>
        /// <param name="value"></param>
        public void Insert(int index, T value)
        {
            if (index < 0 || index > Count) throw new ArgumentOutOfRangeException("index", "索引超出范围");
            var newNode = new Node<T>(value);

            if (index == 0)
            {
                if (_head == null)
                {
                    Add(value);
                    return;
                }
                else
                {
                    // 链表不为空，将其Next指向当前链表的头结点
                    newNode.Next = _head;
                    // 链首重新设置一下
                    _head = newNode;
                }
            }
            else
            {
                // 插入位置不为头部，先查找该位置结点的前驱节点
                var prevNode = GetNodeByIndex(index - 1);
                // 新结点对象取代当前位置结点
                // 先将新结点独享的Next指针，指向当前位置的节点
                newNode.Next = prevNode.Next;
                // 讲前驱节点的Next重新指向新结点
                prevNode.Next = newNode;
            }

            Count++;
        }

    }
}