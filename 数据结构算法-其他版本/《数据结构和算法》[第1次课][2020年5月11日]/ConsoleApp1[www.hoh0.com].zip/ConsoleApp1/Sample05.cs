﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class Sample05
    {
        // n 表示数组 array 的长度
        public int Find(int[] array, int n, int x) {
            var i = 0;
            var pos = -1;
            for (; i < n; ++i) {
                if (array[i] == x) 
                    pos = i;
            }
            return pos;
        }

        // 1/2
        // 0~n-1  这是n个位置
        // 1/2n
        // O(n)
        public int Find2(int[] array, int n, int x) {
            var i = 0;
            var pos = -1;
            for (; i < n; ++i) {
                if (array[i] == x)
                {
                    pos = i;
                    break;
                }
            }
            return pos;
        }
    }
}
