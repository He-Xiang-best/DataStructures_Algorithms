﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class Sample04
    {
        // O(n)
        // O(1)
        // O(n^2)
        public static void Demo(int n)
        {
            var a = new int[n];
            var i = 0;
            for (; i <n; ++i) {
                a[i] = i * i;
            }

            for (i = n-1; i >= 0; --i) {
                Console.WriteLine(a[i]);
            }
        }
    }
}
