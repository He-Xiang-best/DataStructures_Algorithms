﻿namespace ConsoleApp1
{
    public static class Sample01
    { 
        // T(n) = O(f(n))
        // O(2n+2) 单位时间
        // O(n)
        public static int Demo1(int n) {
            // 单位时间  unit time

            // 1
            var sum = 0;
            // 1
            var i = 1;

            // n
            for (; i <= n; ++i) {
                // n
                sum += i;
            }
            return sum;
        }

        // O(2n^2+2n+2)
        // O(n^2)
        // 代码执行时间随数据规模增长的变化趋势
        public static int Demo2(int n) {
            // 1
            var sum = 0;
            // 1
            var i = 1;
            // n
            for (; i <= n; ++i)
            {
                // n
                var j = 1;
                // n^2
                for (; j <= n; ++j) {
                    // n^2
                    sum += i * j;
                }
            }
            return sum;
        }

        public static int Demo3(int n) {
            var sum1 = 0;
            var p = 1;   
            for (; p < 100; ++p) {	  
                sum1 += p;	        	
            }

            // O(n)
            var sum2 = 0;		
            var q = 1;		    
            for (; q < n; ++q) {	    
                sum2 += q;	      
            }
            
            // O(n^2)
            var sum3 = 0;		
            var i = 1;	    	
            for (; i <= n; ++i)	   
            {
                var j = 1;		       
                for (; j <= n; ++j) {   
                    sum3 += i * j;		
                }
            }
            return sum1 + sum2 + sum3;

        }

    }
}