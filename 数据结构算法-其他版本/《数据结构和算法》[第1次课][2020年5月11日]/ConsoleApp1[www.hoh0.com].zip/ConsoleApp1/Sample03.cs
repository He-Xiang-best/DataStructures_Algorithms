﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public static class Sample03
    {
        // O(1)
        public static void Demo1()
        {
            var i = 8;
            var j = 6;
            var sum = i + j;
        }

        //O(n log n)
        public static void Demo2(int n)
        {
            var i = 1;
            while (i <= n)  {
                i = i * 3;
            }

            // 2^0  2^1  2^2  2^x……=n
            // x = log10n
        }

        //O(m+n)
        public static int Demo3(int m, int n)
        {
            var sum1 = 0;
            var i = 1;
            for (; i < m; ++i) {
                sum1 += i;
            }

            var sum2 = 0;
            var j = 1;
            for (; j < n; ++j) {
                sum2 += j;
            }
            return sum1 + sum2;
        }
        
    }
}
