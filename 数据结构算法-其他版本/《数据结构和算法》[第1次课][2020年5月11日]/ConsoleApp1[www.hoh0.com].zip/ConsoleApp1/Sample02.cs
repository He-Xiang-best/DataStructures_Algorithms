﻿namespace ConsoleApp1
{
    public static class Sample02
    {
        // O(n^2)
        public static int Cal(int n) {
            var ret = 0;  
            var i = 1;	
            for (; i < n; ++i) {
                ret += F(i);	
            }
            return ret;
        } 

        // O(n)
        public static int F(int n) {
            var sum = 0;
            var i = 1;	
            for (; i < n; ++i) {
                sum += i;		
            } 
            return sum;
        }
    }
}